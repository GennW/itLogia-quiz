const config = {
    secret: '78d9qw0aps798yfoai7yflvvVD',
    rightOptions: {
        1: [2, 6, 11, 16, 20, 25],
        2: [29, 30, 35, 36, 39],
        3: [42, 47, 52, 55, 58],
    }
};

module.exports = config;